function setup() { 
  createCanvas(400, 400);
} 

function draw() { 
  background('white');
	
	fill('black')
rect(100,130,100,200)
	fill('white')
ellipse(150,165,45,45)
ellipse(150,225,45,45)
ellipse(150,285,45,45)
	fill('grey')
rect(140,330,20,410)

}