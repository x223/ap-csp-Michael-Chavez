function setup() {
  createCanvas(windowWidth, windowHeight);
}

function draw() {
  background(0);
  strokeWeight(4);
  stroke(255);

  y = 40;
  for (var x = 25; x < windowWidth; x = x + 50) {
    for (var y = 25; y < windowHeight; y = y + 50) {
      fill ('blue')
      ellipse(x, y, 40, 40);
    }

  }
}
